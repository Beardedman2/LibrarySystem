from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from .models import Book
from .forms import BookForm, RegisterForm
from django.contrib import messages
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.db.models import Q
from django.contrib.admin.views.decorators import staff_member_required
from .models import Book
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm

@login_required
def home(request):
    query = request.GET.get('q')  # search query
    filter_status = request.GET.get('status')  # availability filter

    books = Book.objects.all()

    # Search by title or author
    if query:
        books = books.filter(Q(title__icontains=query) | Q(author__icontains=query))

    if filter_status == 'available':
        books = [book for book in books if book.available_copies() > 0]
    elif filter_status == 'borrowed':
        books = [book for book in books if book.available_copies() == 0]

    context = {
        'books': books,
        'query': query,
        'filter_status': filter_status,
    }
    return render(request, 'library/home.html', context)

@login_required
def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = BookForm()
    return render(request, 'library/add_book.html', {'form': form})

def register_view(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  
            messages.success(request, f"Welcome, {user.username}!")
            return redirect('home')
    else:
        form = UserCreationForm()
    return render(request, 'library/register.html', {'form': form})


def login_view(request):
    if request.method == "POST":
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, f"Welcome back, {user.username}!")
            return redirect('home')
        else:
            messages.error(request, "Invalid username or password")
    else:
        form = AuthenticationForm()
    return render(request, 'library/login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('login')

@login_required(login_url='login')
def home(request):
    books = Book.objects.all()
    return render(request, 'library/home.html', {'books': books})

@login_required(login_url='login')
def add_book(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Book added successfully!')
            return redirect('home')
    else:
        form = BookForm()
    return render(request, 'library/add_book.html', {'form': form})

@login_required(login_url='login')
@login_required
def borrow_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if not book.is_borrowed:
        book.is_borrowed = True
        book.borrowed_by = request.user
        book.save()
        messages.success(request, f'You borrowed "{book.title}"!')
    else:
        messages.warning(request, f'"{book.title}" is already borrowed.')
    return redirect('home')



@login_required(login_url='login')
def return_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if book.is_borrowed and book.borrowed_by == request.user:
        book.is_borrowed = False
        book.borrowed_by = None
        book.save()
        messages.success(request, f'You returned "{book.title}" successfully.')
    else:
        messages.error(request, "You can't return this book.")
    return redirect('home')


@staff_member_required
def edit_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES, instance=book)
        if form.is_valid():
            form.save()
            messages.success(request, f'"{book.title}" was updated successfully.')
            return redirect('home')
    else:
        form = BookForm(instance=book)
    return render(request, 'library/edit_book.html', {'form': form, 'book': book})


@staff_member_required
def delete_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)
    if request.method == 'POST':
        book.delete()
        messages.success(request, f'"{book.title}" was deleted successfully.')
        return redirect('home')
    return render(request, 'library/delete_book.html', {'book': book})

from django.contrib.auth.models import User
from django.contrib.admin.views.decorators import staff_member_required


@staff_member_required
def admin_dashboard(request):
    books = Book.objects.all()
    
   
    recent_borrows = Book.objects.filter(is_borrowed=True).order_by('-created_at')[:5]

    total_books = books.count()
    borrowed_books = books.filter(is_borrowed=True).count()
    available_books = total_books - borrowed_books
    total_users = User.objects.count()

    context = {
        'books': books,
        'recent_borrows': recent_borrows,
        'total_books': total_books,
        'borrowed_books': borrowed_books,
        'available_books': available_books,
        'total_users': total_users,
    }
    return render(request, 'library/admin_dashboard.html', context)

def my_borrowed_books(request):
    
    borrowed_books = Book.objects.filter(borrowed_by=request.user)
    return render(request, 'library/my_borrowed_books.html', {'books': borrowed_books})

@login_required
def borrow_book(request, book_id):
    book = get_object_or_404(Book, id=book_id)

    
    borrowed_count = Book.objects.filter(borrowed_by=request.user).count()

    if borrowed_count >= 5:
        messages.warning(request, "You can only borrow up to 5 books at a time.")
        return redirect('home')

    if book.is_borrowed:
        messages.warning(request, f'"{book.title}" is already borrowed.')
    else:
        book.is_borrowed = True
        book.borrowed_by = request.user
        book.save()
        messages.success(request, f'You borrowed "{book.title}"!')

    return redirect('home')
