from django.contrib import admin
from .models import Book
from django.utils.html import format_html
# Register your models here.
from django.contrib import admin




@admin.register(Book)
class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'author', 'created_at', 'is_borrowed', 'borrowed_by')
    list_filter = ('is_borrowed', 'author')
    search_fields = ('title', 'author')
